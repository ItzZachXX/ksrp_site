# Kentucky State Roleplay website

Static site for GitHub Pages. It has no server of its own: it talks to the bot's API (running on BisectHosting).

## Set up
1. Edit `js/config.js` and set `api` to your API address, for example `https://api.kentuckyrp.com`.
2. Create a file named `CNAME` containing only your domain, for example `kentuckyrp.com`.
3. Push this folder to a GitHub repository (the repository root must be this folder).
4. Repository Settings, Pages: deploy from the `main` branch, root. Set the custom domain and tick Enforce HTTPS.
5. In your DNS, point the domain at GitHub Pages (see GitHub's custom domain docs).

The staff portal only works when the site and the API share a domain, for example `kentuckyrp.com` and
`api.kentuckyrp.com`. A plain `username.github.io` address will not work for login, because browsers block the
login cookie across different domains.
